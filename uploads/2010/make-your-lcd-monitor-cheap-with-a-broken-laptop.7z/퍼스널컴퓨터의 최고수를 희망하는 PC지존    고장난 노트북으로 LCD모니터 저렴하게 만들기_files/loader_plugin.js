
document.writeln("<div class='mixup_widget' style='padding:20px 0px 20px 0px; text-align:center;'>");
document.writeln("<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0' width='400' height='89' align='middle'>");
document.writeln("<param name='allowScriptAccess' value='always'/>");
document.writeln("<param name='movie' value='http://www.mixsh.com/widget/mixup/loader_plugin.html?domain=pcking.tistory.com&media_type=10&guid=pcking.tistory.com/333&regts=1265775752&showhitcnt=1&platform=11'/>");
document.writeln("<param name='quality' value='high'/>");
document.writeln("<param name='wmode' value='window'/>"); 				
document.writeln("<embed src='http://www.mixsh.com/widget/mixup/loader_plugin.html?domain=pcking.tistory.com&media_type=10&guid=pcking.tistory.com/333&regts=1265775752&showhitcnt=1&platform=11' quality='high' wmode='window' width='400' height='89' allowScriptAccess='always' type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer'/>");
document.writeln("</object>");
document.writeln("</div>");
