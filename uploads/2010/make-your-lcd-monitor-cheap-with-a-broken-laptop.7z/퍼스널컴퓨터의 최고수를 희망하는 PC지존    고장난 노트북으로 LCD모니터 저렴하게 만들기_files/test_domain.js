(function(){window.google_new_domain_enabled=1;})()
