<?php
/*
 Plugin Name: 로그인 메시지 변경
Plugin URI: http://없어도-된다
Description: 로그인 메시지를 변경하는 예제 플러그인다.
Version: 1.0.0
Author: mytory
Author URI: http://mytory.co.kr
License: GPL2
*/

/* Copyright 2012 녹풍 (email : mytory@gmail.com)
 This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/

function modify_login_message($msg){
	$msg .= '나 말곤 아무도 로그인하지 마!';
	return $msg;
}
add_filter('login_message', 'modify_login_message');