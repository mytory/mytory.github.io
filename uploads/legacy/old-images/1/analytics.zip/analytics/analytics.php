<?php
require_once('analytics_api.php');

$login = '-enter login here-';
$password = '-enter password here-';

$modified = @filemtime("cache.txt");

$modified = date("d-m-Y", $modified);
$current = date("d-m-Y");


if ($modified && ($current == $modified)) {
	$cache = @file_get_contents("cache.txt");
} else {
	$cache = null;
}

if (!$cache) {
	$api = new analytics_api();
	if($api->login($login, $password)) {
		$api->load_accounts();
		$accounts = $api->accounts;

		$return = array();
		
		foreach ($accounts as $accountname => $account) {
			$data = $api->data($account['tableId'], 'ga:week', 'ga:visits', 'ga:week', '2009-07-05', '', '52');
			$return[$accountname]['label'] = $accountname;
			
			foreach ($data as $week_number => $week) { 
				$return[$accountname]['data'][] = array( (strtotime("2009W".$week_number) * 1000) , $week['ga:visits']);
			}
		}
		
		$encoded = json_encode($return);
		
		echo $encoded;
		file_put_contents("cache.txt", $encoded);
	}
} else {
	echo $cache;
}


function er($data) {
	echo "<pre>";
	print_r($data);
	echo "</pre>";
}

?>