/* Layout
 ------------ */
* {
	/* Reset browsers default margin, padding and font sizes */
	margin: 0;
	padding: 0;
        
}

html {
	font-size: 100%;
        background:#D2C9AA url(images/htmlbg.jpg);
        background-repeat: repeat-x;
}

body {
	font-family: "Lucida Grande", Verdana, Helvetica, Arial, sans-serif;
 	color: #000000;
	background-color: #FFFFFF;
	font-size: 62.5%; /* This sets the default font size to be equivalent to 10px */
	margin: 15px 15px 10px 15px;
        padding: 0px;
        border-color: #625239;
	border-width: 2px 2px 2px 2px;
	border-style: solid;
}
#wrapheader {
	min-height: 120px;
	height: auto !important;
	height: 120px;
	background-repeat: repeat-x;*/
/*	padding: 0 25px 15px 25px;*/
	padding: 0;
}

#wrapcentre {
	margin: 25px 16px 0 16px;
}

#wrapfooter {
	text-align: center;
	clear: both;
        padding: 10px;

}

#wrapnav {
        font-size: 70.5%;
	width: 100%;
	margin: 0;
	background-color: #FFFFFF;
	border-width: 1px;
	border-style: solid;
	border-color: #000000;
}

#logodesc {
	margin-bottom: 15px;
	padding: 18px 0px 20px 10px;
	background: #FFFFFF;
}

#login_bar{
	margin: 15px 16px 0px 16px;
        border: 1px solid #DCDCC2;
        background: #EAEADA;
        padding:5px;
}

.login_table {
        font-size: 10px;
}

.login_inner_table{
        padding: 10px 5px 10px 5px;
	background: #D2C9AA;
        border: 1px solid #BAAC7C;
}


#datebar {
        font-size: 0.9em;
        color:#555555;
        margin: 0px 15px -5px 15px; 
}

#findbar {
	width: 100%;
	margin: 0;
	padding: 0;
	border: 0;
}

.forumrules {
	background-color: #FFFFFF;
	border-width: 0px;
	padding: 4px;
	font-weight: normal;
	font-size: 1.1em;
	font-family: "Lucida Grande", Verdana, Arial, Helvetica, sans-serif;
}

.breadcrumbs{
	color: #000000;
	font-size: 2em;
	font-weight: bold;
}

#pageheader { }
#pagecontent { }
#pagefooter { }

#poll { }
#postrow { }
#postdata { }


/*  Text
 --------------------- */
h1 {
	color: #000000;
	font-family: "Lucida Grande", "Trebuchet MS", Verdana, sans-serif;
	font-weight: bold;
	font-size: 3.2em;
	text-decoration: none;
}
.sub_title {
        color: #727272;
	font-family: "Lucida Grande", "Trebuchet MS", Verdana, sans-serif;
	font-weight: normal;
	font-size: 1.4em;
	text-decoration: none;
}

h2 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 2.6em;
	text-decoration: none;
	line-height: 120%;
}

h3 {
	font-size: 1.3em;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	line-height: 120%;
}

h4 {
	margin: 0;
	font-size: 1.1em;
	font-weight: bold;
}

.main_nav {
	font-size: 1.5em;
        padding: 3px 0px 28px 0px;
        background-image:url(images/nav_bg.gif);
        background-repeat: repeat-x;
}

p {
	font-size: 1.1em;
}

p.moderators {
	margin: 0;
	float: left;
	color: #FCC263;
	font-weight: bold;
}

.rtl p.moderators {
	float: right;
}

p.linkmcp {
	margin: 0;
	float: right;
	white-space: nowrap;
}

.rtl p.linkmcp {
	float: left;
}

p.breadcrumbs {
	margin: 0;
	float: left;
	color: black;
	font-weight: bold;
	white-space: normal;
	font-size: 1.5em;
}

.rtl p.breadcrumbs {
	float: right;
}

p.datetime {
	margin: 0;
	float: right;
	font-size: 1.2em;
}

.rtl p.datetime {
	float: left;
}

p.searchbar {
	padding: 5px 0px 10px 0px;
	white-space: nowrap;
        font-size: 1.1em;
        font-weight: bold;
} 

p.searchbarreg {
	margin: 0;
	float: right;
	white-space: nowrap;
}

.rtl p.searchbarreg {
	float: left;
}

p.forumsub {
	padding-bottom: 4px;
}

p.forumdesc {
	color: #999999;
	padding-bottom: 10px;
}

p.topicauthor {
	margin: 1px 0;
}

p.topicdetails {
	margin: 1px 0;
}

.postreported, .postreported a:visited, .postreported a:hover, .postreported a:link, .postreported a:active {
	margin: 1px 0;
	color: red;
	font-weight:bold;
}

.postapprove, .postapprove a:visited, .postapprove a:hover, .postapprove a:link, .postapprove a:active {
	color: green;
	font-weight:bold;
}

.postapprove img, .postreported img {
	vertical-align: bottom;
}

.postauthor {
	color: #000000;
        font-size: 1.5em;
        padding: 0px 0px 0px 9px;
}

.postdetails {
	color: #000000;
}

.postbody {
	font-size: 1.3em;
	line-height: 1.4em;
	font-family: "Lucida Grande", "Trebuchet MS", Helvetica, Arial, sans-serif;
}


.postbody li, ol, ul {
	margin: 0 0 0 1.5em;
}


.rtl .postbody li, .rtl ol, .rtl ul {
	margin: 0 1.5em 0 0;
}

.posthilit {
	background-color: #FDD99B;
	color: #000000;
}

.nav {
	margin: 0;
	color: #000000;
	font-weight: bold;
}

.pagination {
	padding: 4px;
	color: black;
	font-size: 1em;
	font-weight: bold;
}

.gen {
	margin: 1px 1px;
	font-size: 1.2em;
}

.genmed {
	margin: 1px 1px;
	font-size: 1.1em;
}

.gensmall {
	margin: 1px 1px;
	font-size: 1em;
}

.tinytext{
        margin: 1px 1px;
	font-size: 0.9em;
}

.copyright {
	color: #000000;
	font-weight: normal;
	font-family: "Lucida Grande", Verdana, Arial, Helvetica, sans-serif;
}


.error {
	color: red;
}


/* Tables
 ------------ */
th {
	color: #000000;
	font-size: 1.1em;
	font-weight: bold;
	background-color: #D2C9AA;
	white-space: nowrap;
	padding: 7px 5px;
}

td {
	padding: 2px;
}
td.profile {
	padding: 4px;
        background-color: #EAEADA;
}

.tablebg {
	background-color: #DCDCC2;
}

.catdiv {
	height: 28px;
	margin: 0;
	padding: 0;
	border: 0;
	background-color: #EAEADA;
}
.rtl .catdiv {
	background-color: #EAEADA;
}

.cat {
	height: 28px;
	margin: 0;
	padding: 0;
	border: 0;
	background-color: #EAEADA;
	text-indent: 10px;
}

.row1 {
	background-color: #FBFBFB;
	padding: 4px;
}

.row2 {
	background-color: #FBFBFB;
	padding: 4px;
}

.row3 {
	background-color: #EAEADA;
	padding: 4px;
}

.rowgood {
	background-color: #EBFBDB;
	padding: 4px;
}

.rowneutral {
	background-color: #FFFFFF;
	padding: 4px;
}

.rowbad {
	background-color: #FBE0DB;
	padding: 4px;
}

.spacer {
	background-color: #796646;
        padding: 1px;
}

hr {
	height: 1px;
	border-width: 0;
	background-color: #FFFFFF;
	color: #796646;
}

.legend {
	text-align:center;
	margin: 0 auto;
}

/* Links
 ------------ */
a:link {
	color: #000000;
	text-decoration: none;
}

a:active,
a:visited {
	color: #000000;
	text-decoration: none;
}

a:hover {
        text-decoration: underline;
}

a.forumlink {
	color: #000000;
	font-weight: bold;
	font-family: "Lucida Grande", Helvetica, Arial, sans-serif;
	font-size: 1.2em;
}

a.topictitle {
	margin: 1px 0;
	font-family: "Lucida Grande", Helvetica, Arial, sans-serif;
	font-weight: bold;
	font-size: 1.2em;
}

a.topictitle:visited {
	text-decoration: none;
}

th a,
th a:visited {
	color: #000000 !important;
	text-decoration: none;
}

th a:hover {
	text-decoration: underline;
}
/* 포럼 내 밑줄 표시 : 2008-11-12 재성 */
a.postlink {text-decoration: underline;}
a.postlink:link, a.postlink:visited {color:#a44}
a.postlink:hover, a.postlink:active {color:#000}

/* 포럼 내부 링크 밑줄 표시 : 2009-02-14 Mr.Dust */
a.postlink-local {text-decoration: underline;}
a.postlink-local:link, a.postlink:visited {color:#a44}
a.postlink-local:hover, a.postlink:active {color:#000}


/* Form Elements
 ------------ */
form {
	margin: 0;
	padding: 0;
	border: 0;
}

input {
	color: #000000;
	font-family: "Lucida Grande", Verdana, Helvetica, sans-serif;
	font-size: 1.1em;
	font-weight: normal;
	padding: 1px;
	border: 1px solid #C5C5C5;
	background-color: #FFFFFF;
}

textarea {
	background-color: #FFFFFF;
	color: #000000;
	font-family: "Lucida Grande", Verdana, Helvetica, Arial, sans-serif;
	font-size: 1.3em; 
	line-height: 1.4em;
	font-weight: normal;
	border: 1px solid #C5C5C5;
	padding: 2px;
}

select {
	color: #000000;
	background-color: #FFFFFF;
	font-family: "Lucida Grande", Verdana, Helvetica, sans-serif;
	font-size: 1.1em;
	font-weight: normal;
	border: 1px solid #C5C5C5;
	padding: 1px;
}

option {
	padding: 0 1em 0 0;
}

.rtl option {
	padding: 0 0 0 1em;
}

input.radio {
	border: none;
	background-color: transparent;
}

.post {
	background-color: #FFFFFF;
	border: 1px solid #C5C5C5;
        color: #000000;
}

.btnbbcode {
	color: #000000;
	font-weight: normal;
	font-size: 1.1em;
	font-family: "Lucida Grande", Verdana, Helvetica, sans-serif;
	background-color: #FFFFFF;
	border: 1px solid #C5C5C5;
}

.btnmain {
        color: #000000;
	font-weight: bold;
	background-color: #FFFFFF;
	border: 1px solid #C5C5C5;
	cursor: pointer;
	padding: 1px 5px;
	font-size: 1.1em;
        height: 3em;
}

.btnlite {
        color: #000000;
	font-weight: bold;
        font-family: "Lucida Grande", Verdana, Helvetica, sans-serif;
	background-color: #FFFFFF;
	border: 1px solid #C5C5C5;
	cursor: pointer;
	padding: 1px 5px;
	font-size: 1.0em;
}

.btnfile {
        color: #000000;
	font-weight: normal;
	background-color: #FFFFFF;
	border: 1px solid #C5C5C5;
	padding: 1px 5px;
	font-size: 1.1em;
}

.helpline {
	background-color: #EAEADA;
	border: 1px solid #DCDCC2;
        color: #000000;
        padding: 5px;
}


/* BBCode
 ------------ */
.quotetitle, .attachtitle {
	margin: 10px 5px 0 5px;
	padding: 4px;
	border-width: 1px 1px 0px 1px;
	border-style: solid;
	border-color: #DDDDC5;
	color: #000000;
	background-color: #DDDDC5;
	font-size: 0.85em;
	font-weight: bold;
}

.quotetitle .quotetitle {
	font-size: 1em;
}

.quotecontent, .attachcontent {
	margin: 0 5px 10px 5px;
	padding: 5px;
	border-color: #DDDDC5;
	border-width: 0 1px 1px 1px;
	border-style: solid;
	font-weight: normal;
	font-size: 1em;
	line-height: 1.4em;
	font-family: "Lucida Grande", "Trebuchet MS", Helvetica, Arial, sans-serif;
	background-color: #F8F8F3;
	color: #000000;
}

.attachcontent {
	font-size: 0.85em;
}

.codetitle {
	margin: 10px 5px 0 5px;
	padding: 2px 4px;
	border-width: 1px 1px 0 1px;
	border-style: solid;
	border-color: #DDDDC5;
	color: #000000;
	background-color: #DDDDC5;
	font-family: "Lucida Grande", Verdana, Helvetica, Arial, sans-serif;
	font-size: 0.8em;
}

.codecontent {
	direction: ltr;
	margin: 0 5px 10px 5px;
	padding: 5px;
	border-color: #DDDDC5;
	border-width: 0 1px 1px 1px;
	border-style: solid;
	font-weight: normal;
	color: #000000;
	font-size: 0.85em;
	font-family: Monaco, 'Courier New', monospace;
	background-color: #F8F8F3;
}

.syntaxbg {
	color: #FFFFFF;
}

.syntaxcomment {
	color: #FF8000;
}

.syntaxdefault {
	color: #0000BB;
}

.syntaxhtml {
	color: #000000;
}

.syntaxkeyword {
	color: #006633;
}

.syntaxstring {
	color: #990000;
}


/* Private messages
 ------------------ */
.pm_marked_colour {
	background-color: #FDD99B;
}

.pm_replied_colour {
	background-color: #EAEADA;
}

.pm_friend_colour {
	background-color: #D2C9AA;
}

.pm_foe_colour {
	background-color: #DB0900;
}


/* Misc
 ------------ */
img {
	border: none;
}

.sep {
	color: black;
	background-color: #FFA34F;
}

table.colortable td {
	padding: 0;
}

pre {
	font-size: 1.1em;
	font-family: Monaco, 'Courier New', monospace;
}

.nowrap {
	white-space: nowrap;
}

.username-coloured {
	font-weight: bold;
}

.subforum.read {  
	background: url(images/icon_post_target.gif) center left no-repeat;  
	padding-left: 12px;  
}  

.subforum.unread {  
	background: url(images/icon_post_target_unread.gif) center left no-repeat;  
	padding-left: 12px;  
}