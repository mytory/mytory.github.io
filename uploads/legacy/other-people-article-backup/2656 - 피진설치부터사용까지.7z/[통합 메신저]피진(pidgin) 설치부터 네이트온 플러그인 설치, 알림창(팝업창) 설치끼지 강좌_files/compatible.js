 /**
 * Copyright 2007 SK Communications. All rights reserved
 * @since 2007.08.01
 * @author okjungsoo
 * 
 */
 
function imgview(src, width, height, slt) {
	return Control.Modal.openDialog(this, null, src);
}