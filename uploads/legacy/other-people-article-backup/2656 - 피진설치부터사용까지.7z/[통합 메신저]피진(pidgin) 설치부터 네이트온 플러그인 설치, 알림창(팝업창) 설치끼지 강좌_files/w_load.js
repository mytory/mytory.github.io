var t = new Date().getTime();
document.write('<div id="w_div_' + t + '"></div>');
var s = new WZD_W_SWFObject('http://flash.adjet.wzdwidget.com/swf/cbfd14b4c255fe1d/weatherclock.swf?a_aid=cbfd14b4c255fe1d&a_rid=73e727365b77d66e&a_url=http%253A%252F%252Flithiumion.egloos.com%252F4682184&a_colorset=1&a_contents=weatherclock&a_counter=show&a_counter_value=5285&a_location=KSXX0017&a_tempunit=c', 'w_swf_' + t, '150', '120', '8', '#ffffff');
s.write('w_div_' + t);
